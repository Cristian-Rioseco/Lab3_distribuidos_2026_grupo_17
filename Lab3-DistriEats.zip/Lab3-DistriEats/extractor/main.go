package main

import (
	"context"
	"database/sql"
	"encoding/json"
	"fmt"
	"log"
	"os"
	"strconv"
	"time"

	_ "github.com/lib/pq"
	amqp "github.com/rabbitmq/amqp091-go"
)

type EventoPedido struct {
	IdPedido         string `json:"id_pedido"`
	Cadena           string `json:"cadena"`
	Estado           string `json:"estado"`
	TimestampEmision string `json:"timestamp_emision"`
}

func getEnv(key, fallback string) string {
	if val := os.Getenv(key); val != "" {
		return val
	}
	return fallback
}

func conectarPostgres() *sql.DB {
	host := getEnv("DB_HOST", "localhost")
	port := getEnv("DB_PORT", "5432")
	//Credenciales
	user := getEnv("DB_USER", "distrieats_lector")
	pass := getEnv("DB_PASS", "lector_lab3_2026")
	dbname := getEnv("DB_NAME", "distrieats")

	dsn := fmt.Sprintf("host=%s port=%s user=%s password=%s dbname=%s sslmode=disable",
		host, port, user, pass, dbname)

	for {
		db, err := sql.Open("postgres", dsn)
		if err == nil {
			if err = db.Ping(); err == nil {
				log.Println("[EXTRACTOR] Conectado exitosamente a PostgreSQL")
				return db
			}
			db.Close()
		}
		log.Printf("[EXTRACTOR] Esperando a PostgreSQL (%v)... reintentando en 3s", err)
		time.Sleep(3 * time.Second)
	}
}

func conectarRabbitMQ() (*amqp.Connection, *amqp.Channel) {
	rabbitURL := getEnv("RABBITMQ_URL", "amqp://guest:guest@localhost:5672/")

	for {
		conn, err := amqp.Dial(rabbitURL)
		if err == nil {
			ch, err := conn.Channel()
			if err == nil {
				log.Println("[EXTRACTOR] Conectado exitosamente a RabbitMQ")
				return conn, ch
			}
			conn.Close()
		}
		log.Printf("[EXTRACTOR] Esperando a RabbitMQ (%v)... reintentando en 3s", err)
		time.Sleep(3 * time.Second)
	}
}

func main() {
	tabla := getEnv("DB_TABLE_HISTORICO", "pedidos_historicos")
	cola := getEnv("RABBITMQ_QUEUE_HISTORICO", "historico_queue")

	tamanoPagina, err := strconv.Atoi(getEnv("TAMANO_PAGINA", "1000"))
	if err != nil || tamanoPagina <= 0 {
		tamanoPagina = 1000
	}

	pausaMilisegundos, err := strconv.Atoi(getEnv("PAUSA_PAGINA_MS", "500"))
	if err != nil || pausaMilisegundos < 0 {
		pausaMilisegundos = 500
	}

	//conecto servicios
	db := conectarPostgres()
	defer db.Close()

	conn, ch := conectarRabbitMQ()
	defer conn.Close()
	defer ch.Close()

	_, err = ch.QueueDeclare(
		cola,  // name
		true,  // durable
		false, // delete when unused
		false, // exclusive
		false, // no-wait
		nil,   // arguments
	)
	if err != nil {
		log.Fatalf("[EXTRACTOR] Error declarando cola %s: %v", cola, err)
	}

	ultimoID := 0
	paginasProcesadas := 0
	totalExtraido := 0

	log.Printf("[EXTRACTOR] Iniciando extracción masiva paginada desde '%s' hacia '%s' (Bloques de %d)", tabla, cola, tamanoPagina)

	for {
		query := fmt.Sprintf(`
			SELECT id, id_pedido, cadena, estado, timestamp_emision::text
			FROM %s
			WHERE id > $1
			ORDER BY id ASC
			LIMIT $2`, tabla)

		rows, err := db.Query(query, ultimoID, tamanoPagina)
		if err != nil {
			log.Printf("[EXTRACTOR] Error consultando BD: %v. Reintentando en 3s...", err)
			time.Sleep(3 * time.Second)
			continue
		}

		registrosEnBloque := 0

		for rows.Next() {
			var id int
			var idPedido, cadena, estado, tsEmision sql.NullString

			if err := rows.Scan(&id, &idPedido, &cadena, &estado, &tsEmision); err != nil {
				log.Printf("[EXTRACTOR] Error escaneando fila: %v", err)
				continue
			}

			evento := EventoPedido{
				IdPedido:         idPedido.String,
				Cadena:           cadena.String,
				Estado:           estado.String,
				TimestampEmision: tsEmision.String,
			}

			body, err := json.Marshal(evento)
			if err != nil {
				log.Printf("[EXTRACTOR] Error serializando evento ID %d: %v", id, err)
				continue
			}

			// Publicar masivamente
			for {
				ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
				err = ch.PublishWithContext(
					ctx,
					"",    // exchange
					cola,  // routing key
					false, // mandatory
					false, // immediate
					amqp.Publishing{
						ContentType:  "application/json",
						DeliveryMode: amqp.Persistent, // Asegura que no se pierdan si RabbitMQ se reinicia
						Body:         body,
					},
				)
				cancel()

				if err == nil {
					break
				}

				log.Printf("[EXTRACTOR] Error publicando en RabbitMQ (%v). Reconectando...", err)
				ch.Close()
				conn.Close()
				conn, ch = conectarRabbitMQ()
			}

			ultimoID = id
			registrosEnBloque++
			totalExtraido++
		}
		rows.Close()

		if registrosEnBloque == 0 {
			log.Printf("[EXTRACTOR] 🏁 Fin de tabla alcanzado. Total de registros históricos inyectados: %d", totalExtraido)
			break
		}

		paginasProcesadas++
		log.Printf("[EXTRACTOR] Bloque %d procesado (%d registros). Último ID procesado: %d. Pausando %d ms...",
			paginasProcesadas, registrosEnBloque, ultimoID, pausaMilisegundos)

		// Pausa breve para evitar abrumar a RabbitMQ o ahogar el tráfico de la red
		time.Sleep(time.Duration(pausaMilisegundos) * time.Millisecond)
	}
}
